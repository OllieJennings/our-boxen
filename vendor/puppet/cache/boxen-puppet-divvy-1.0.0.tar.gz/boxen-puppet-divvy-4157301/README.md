# Divvy Puppet Module for Boxen

Install [Divvy](http://mizage.com/divvy), a window resizer for Mac OS X.

## Usage

```puppet
include divvy
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
